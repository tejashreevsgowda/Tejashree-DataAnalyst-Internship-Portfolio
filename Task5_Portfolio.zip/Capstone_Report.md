
# ApexPlanet Data Analytics Internship — Capstone Report

## Project Overview
This capstone consolidates the sales-data analysis completed
during the internship.

## Business Objective
Understand sales performance and identify useful business
patterns from sales transactions.

## Final KPIs
- Total Sales: 139,399,439.65
- Unique Orders: 992
- Unique Customers: 947
- Average Order Value: 140,523.63

## Key Observations
- Highest-sales category in the dataset: Electronics
- Top product by recorded sales: Laptop

## Skills Demonstrated
- Data cleaning and preparation
- Exploratory data analysis
- KPI calculation
- SQL-based business analysis (from Task 2, if completed)
- Data visualization
- Statistical hypothesis testing (from Task 4, if completed)
- Business reporting and storytelling

## Tools
Python, Pandas, NumPy, Matplotlib, Seaborn, Google Colab, GitHub

## Business Recommendations
Review category and product performance, monitor monthly trends,
and investigate opportunities to improve sales.

## Limitations
These observations describe the supplied dataset. They do not
by themselves establish why a sales pattern occurred.
