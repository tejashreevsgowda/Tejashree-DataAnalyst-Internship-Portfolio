
# Data Analytics Internship Portfolio

## About This Portfolio
This repository brings together my work from the ApexPlanet
60-Days Data Analytics Internship.

## Project Tasks

### Task 1 — Data Immersion & Wrangling
Data profiling, cleaning, transformation, and preparation.

### Task 2 — Exploratory Data Analysis & Business Intelligence
Descriptive statistics, SQL business questions, and visualizations.

### Task 3 — Deep-Dive Analysis & Interactive Dashboarding
Sales KPIs, product and category analysis, and dashboard exploration.

### Task 4 — Data Storytelling & Statistical Validation
Business findings, hypothesis testing, and statistical interpretation.

### Task 5 — Capstone Integration & Portfolio Finalization
Consolidated project summary, final report, and portfolio presentation.

## Tools and Skills
Python, Pandas, NumPy, SQL, Matplotlib, Seaborn, Plotly,
Google Colab, GitHub, data cleaning, EDA, KPI analysis,
statistical testing, and data storytelling.

## Dataset
Sales transaction dataset used for the internship exercises.

## Final Deliverables
Refer to each task folder for its notebook, reports, and outputs.
